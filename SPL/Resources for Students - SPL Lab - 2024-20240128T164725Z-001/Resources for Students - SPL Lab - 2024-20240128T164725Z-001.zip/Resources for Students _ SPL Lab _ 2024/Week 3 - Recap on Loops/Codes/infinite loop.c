#include<stdio.h>
int main()
{
    int i;

    for(i=1; i>0; i++)
    {
        printf("\nI'm stuck in an infinite loop!");
    }
}

